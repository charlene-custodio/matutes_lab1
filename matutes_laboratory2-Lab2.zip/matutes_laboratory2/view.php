<?php
include 'db.php';

// Handle deletion if 'delete' is set in GET
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];

    // Get the image path first
    $imgQuery = mysqli_query($conn, "SELECT image FROM class_schedule WHERE id = $id");
    $imgRow = mysqli_fetch_assoc($imgQuery);
    $imgPath = $imgRow['image'];

    // Delete the record
    $delete = mysqli_query($conn, "DELETE FROM class_schedule WHERE id = $id");

    if ($delete) {
        // Remove image file if it exists
        if (!empty($imgPath) && file_exists($imgPath)) {
            unlink($imgPath);
        }
        echo "<script>alert('Class deleted successfully!'); window.location.href='view.php';</script>";
    } else {
        echo "<script>alert('Error deleting record: " . mysqli_error($conn) . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>View Classes</title>
    <link rel="stylesheet" href="./styles/view.css">
</head>
<body>

<div class="container">
    <a class="top-link" href="index.php">⬅️ Add New Class</a>

    <h2>Class List</h2>

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Image</th>
                <th>Subject</th>
                <th>Schedule</th>
                <th>Classroom</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $result = mysqli_query($conn, "SELECT * FROM class_schedule");
        $counter = 1;
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $counter++ . "</td>";

            $imagePath = (!empty($row['image']) && file_exists($row['image']))
                ? $row['image']
                : 'uploads/placeholder.jpg';

            echo "<td><img src='" . $imagePath . "' alt='Class Image' style='width: 60px; height: auto;'></td>";
            echo "<td>" . htmlspecialchars($row['subject']) . "</td>";
            echo "<td>" . htmlspecialchars($row['schedule']) . "</td>";
            echo "<td>" . htmlspecialchars($row['classroom']) . "</td>";
            echo "<td>  
                    <a class='button' href='edit.php?id=" . $row['id'] . "'>Edit</a>
                    <a class='button delete' href='view.php?delete=" . $row['id'] . "' onclick='return confirm(\"Are you sure you want to delete this class?\");'>Delete</a>
                </td>";
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>
</div>

</body>
</html>
