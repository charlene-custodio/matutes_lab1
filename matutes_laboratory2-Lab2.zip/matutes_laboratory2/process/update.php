<?php
include '../db.php';

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $subject = $_POST['subject'];
    $schedule = $_POST['schedule'];
    $classroom = $_POST['classroom'];

    $imageSQL = "";
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $targetDir = '../uploads/';
        $filename = basename($_FILES["image"]["name"]);
        $fullPath = $targetDir . $filename;

        // Try to move the uploaded file
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $fullPath)) {
            $relativePath = 'uploads/' . $filename; // Store relative path
            $relativePath = mysqli_real_escape_string($conn, $relativePath);
            $imageSQL = ", image='$relativePath'";
        }
    }

    $update_query = "UPDATE class_schedule SET 
                        subject='$subject', 
                        schedule='$schedule', 
                        classroom='$classroom'
                        $imageSQL
                    WHERE id=$id";

    if (mysqli_query($conn, $update_query)) {
        echo "<script>alert('Class updated successfully!'); window.location.href='../view.php';</script>";
    } else {
        echo "<script>alert('Error updating record: " . mysqli_error($conn) . "');</script>";
    }
}
?>
