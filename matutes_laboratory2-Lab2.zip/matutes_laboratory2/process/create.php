<?php
include '../db.php';

if (isset($_POST['submit'])) {
    $subject = $_POST['subject'];
    $schedule = $_POST['schedule'];
    $classroom = $_POST['classroom'];

    // Handle image upload
    $imagePath = "";
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $targetDir = '../uploads/'; // Store above view.php, index.php
        $filename = basename($_FILES["image"]["name"]);
        $imagePath = $targetDir . $filename;
        $uploadSuccess = move_uploaded_file($_FILES["image"]["tmp_name"], $imagePath);

        // Save the path relative to view.php
        if ($uploadSuccess) {
            $imagePath = 'uploads/' . $filename; // relative path for use in HTML
        } else {
            $imagePath = ''; // fallback in case of error
        }
    }

    $imagePath = mysqli_real_escape_string($conn, $imagePath);
    $sql = "INSERT INTO class_schedule (subject, schedule, classroom, image) 
            VALUES ('$subject', '$schedule', '$classroom', '$imagePath')";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('New class added successfully!'); window.location.href='../view.php';</script>";
    } else {
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
    }
}
?>
