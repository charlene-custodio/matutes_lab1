<?php
include '../db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "DELETE FROM class_schedule WHERE id=$id";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Class deleted successfully!'); window.location.href='../view.php';</script>";
    } else {
        echo "<script>alert('Error deleting record: " . mysqli_error($conn) . "'); window.location.href='../view.php';</script>";
    }
}
?>
