<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>View Classes</title>
    <link rel="stylesheet" href="./styles/view.css">
</head>
<body>

    <div class="container">
        <a class="top-link" href="index.php">⬅️ Add New Class</a>

        <h2>Class List</h2>

        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Subject</th>
                    <th>Schedule</th>
                    <th>Classroom</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $result = mysqli_query($conn, "SELECT * FROM class_schedule");
            $counter = 1;
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $counter++ . "</td>";
                echo "<td>" . htmlspecialchars($row['subject']) . "</td>";
                echo "<td>" . htmlspecialchars($row['schedule']) . "</td>";
                echo "<td>" . htmlspecialchars($row['classroom']) . "</td>";
                echo "<td>
                        <a class='button' href='edit.php?id=" . $row['id'] . "'>Edit</a>
                        <a class='button delete' href='process/delete.php?id=" . $row['id'] . "' onclick='return confirm(\"Are you sure you want to delete this class?\");'>Delete</a>
                      </td>";
                echo "</tr>";
            }
            ?>
            </tbody>
        </table>
    </div>

</body>
</html>
