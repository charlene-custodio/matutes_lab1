<?php
include '../db.php';

if (isset($_POST['submit'])) {
    $subject = $_POST['subject'];
    $schedule = $_POST['schedule'];
    $classroom = $_POST['classroom'];

    $sql = "INSERT INTO class_schedule (subject, schedule, classroom) 
            VALUES ('$subject', '$schedule', '$classroom')";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('New class added successfully!'); window.location.href='../view.php';</script>";
    } else {
        echo "<script>alert('Error: " . mysqli_error($conn) . "'); window.location.href='../index.php';</script>";
    }
}
?>
