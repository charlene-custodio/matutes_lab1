<?php
include '../db.php';

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $subject = $_POST['subject'];
    $schedule = $_POST['schedule'];
    $classroom = $_POST['classroom'];

    $sql = "UPDATE class_schedule SET 
            subject='$subject', 
            schedule='$schedule', 
            classroom='$classroom' 
            WHERE id=$id";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Class updated successfully!'); window.location.href='../view.php';</script>";
    } else {
        echo "<script>alert('Error updating record: " . mysqli_error($conn) . "'); window.location.href='../edit.php?id=$id';</script>";
    }
}
?>
