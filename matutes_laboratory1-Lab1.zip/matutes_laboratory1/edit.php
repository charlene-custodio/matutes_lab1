<?php
include 'db.php';

// Fetch the class info using the ID from URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM class_schedule WHERE id = $id";
    $result = mysqli_query($conn, $query);
    $class = mysqli_fetch_assoc($result);
} else {
    // Redirect back if no ID provided
    header("Location: view.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Class</title>
    <link rel="stylesheet" href="./styles/edit.css">
</head>
<body>

    <div class="container">
        <h2>Edit Class</h2>

        <form method="POST" action="process/update.php">
            <input type="hidden" name="id" value="<?php echo $class['id']; ?>">

            <input type="text" name="subject" value="<?php echo htmlspecialchars($class['subject']); ?>" placeholder="Subject" required>
            <input type="text" name="schedule" value="<?php echo htmlspecialchars($class['schedule']); ?>" placeholder="Schedule" required>
            <input type="text" name="classroom" value="<?php echo htmlspecialchars($class['classroom']); ?>" placeholder="Classroom" required>

            <button type="submit" name="update">Update Class</button>
        </form>

        <a href="view.php">⬅️ Back to Class List</a>
    </div>

</body>
</html>
