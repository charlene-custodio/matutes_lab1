<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add New Class</title>
    <link rel="stylesheet" href="./styles/index.css">
</head>
<body>

    <div class="container">
        <h2>Add New Class</h2>

        <form method="POST" action="process/create.php">
            <input type="text" name="subject" placeholder="Subject" required>
            <input type="text" name="schedule" placeholder="Schedule" required>
            <input type="text" name="classroom" placeholder="Classroom" required>

            <button type="submit" name="submit">Add Class</button>
        </form>

        <a href="view.php">➡️ View Classes</a>
    </div>

</body>
</html>
